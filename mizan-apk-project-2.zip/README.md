# بناء APK لـ «ميزان الغذاء»

## الطريقة 1: بدون تثبيت أي شيء (GitHub)
1. أنشئ حسابًا على github.com ثم مستودعًا جديدًا (Repository) خاصًا.
2. ارفع كل محتويات هذا المجلد كما هي (بما فيها المجلد المخفي `.github`).
3. افتح تبويب **Actions** ثم **Build APK** ثم **Run workflow**.
4. بعد 5 إلى 8 دقائق افتح التشغيل المكتمل ونزّل **mizan-apk** من قسم Artifacts.
5. فك الضغط وانقل `app-debug.apk` إلى الهاتف وثبّته (فعّل «التثبيت من مصادر غير معروفة»).

## الطريقة 2: على جهازك (Node 18+ و Java 17 و Android Studio)
    npm install
    npx cap add android
    npx capacitor-assets generate --android
    npx cap sync android
    cd android && ./gradlew assembleDebug

الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`

## ما يعمل داخل التطبيق
- زر «استرجاع من ملف» في صفحة «احفظ نسختك أو شاركها».
- أزرار التحميل والمشاركة تفتح قائمة مشاركة أندرويد (احفظ في Drive أو الملفات أو أرسل بواتساب).
- ملفات الحفظ تبقى بصيغتها القديمة (HTML) وتعمل مع النسخ القديمة.
